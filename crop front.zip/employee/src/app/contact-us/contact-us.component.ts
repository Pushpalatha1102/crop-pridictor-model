import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.css'
})
export class ContactUsComponent {
    contact = {
      name: '',
      email: '',
      message: ''
    };
  
    constructor(private http: HttpClient) { }
  
    onSubmit() {
      this.http.post('your-backend-url/endpoint', this.contact).subscribe(response => {
        console.log('Response:', response);
        // Reset form or handle response
        this.contact = {
          name: '',
          email: '',
          message: ''
        };
      }, error => {
        console.error('Error:', error);
      });
    }
  
}
